<?php
// GoldOSRS Configuration — edit before deployment

// ── Database ──────────────────────────────────────────────────────────────────
define('DB_HOST', 'db5020043088.hosting-data.io');
define('DB_USER', 'dbu2374102');
define('DB_PASS', 'Hello1337!.');
define('DB_NAME', 'dbs15455817');

// ── Site ──────────────────────────────────────────────────────────────────────
define('SITE_URL', 'https://goldosrs.com');
define('SITE_NAME', 'GoldOSRS');
define('SITE_EMAIL', 'support@goldosrs.com');

// ── Discord ───────────────────────────────────────────────────────────────────
define('DISCORD_WEBHOOK_URL', 'https://discord.com/api/webhooks/1479325926444503152/NLgTADpLvPh0E0YDC8Nkgk6m2YUw3uMUHP4DGiOKyu9BJ18RZjMxfiRtM3xNCRKX8Gf_');
define('DISCORD_BOT_TOKEN', 'YOUR_BOT_TOKEN');         // For reading replies
define('DISCORD_CHANNEL_ID', '1479322839206203415');       // Channel for support chats
define('DISCORD_GUILD_ID', '1479322837520224267');

// ── Bitcoin / Crypto ──────────────────────────────────────────────────────────
define('STATIC_BTC_ADDRESS', 'bc1q24z9a6srfrz4gruancd6akxakwyakmunnqnfqy');  // Fallback if no Electrum
define('STATIC_ETH_ADDRESS', '0xCA5A64be65DD5321e4F1E4f27EA6aaB7Fd0016E4');
define('STATIC_LTC_ADDRESS', 'LYourLtcAddressHere');
define('ELECTRUM_RPC_HOST', 'localhost');
define('ELECTRUM_RPC_PORT', 7777);
define('ELECTRUM_RPC_USER', 'user');
define('ELECTRUM_RPC_PASS', 'password');
define('BTC_CONFIRMATIONS_REQUIRED', 1);

// ── GP/USD conversion ─────────────────────────────────────────────────────────
// How many GP millions does $1 buy (rough, used for deposit crediting)
define('GP_PER_USD', 3.4);  // $1 = ~3.4M OSRS GP at $0.29/M

// ── Email (PHP mail() or SMTP) ────────────────────────────────────────────────
define('MAIL_FROM', 'noreply@goldosrs.com');
define('MAIL_FROM_NAME', 'GoldOSRS');

// ── Session / Security ────────────────────────────────────────────────────────
define('SESSION_NAME', 'goldosrs_sess');
define('RATE_LIMIT_SECONDS', 2);   // Min seconds between same actions

// ── Paths ─────────────────────────────────────────────────────────────────────
define('ROOT_PATH', __DIR__);
define('LOG_PATH', __DIR__ . '/logs');
define('DATA_PATH', __DIR__ . '/data');

// ── Discord cache file (for listener state) ───────────────────────────────────
define('DISCORD_CACHE_FILE', __DIR__ . '/data/discord_last.json');
